
> Login accounts:
>
> - superadmin@mail.com
> - admin@mail.com
> - customer@mail.com
>
>   All passwords are same: `12345@Aa`

## How to run the app

You run `npm start`

## Note

I couldn't upload the node_modules to github because it's too heavy.


