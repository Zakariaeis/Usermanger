export { ForbiddenComponent as ForbiddenPage } from './forbidden/forbidden.component';
export { NotFoundComponent as NotfoundPage } from './not-found/not-found.component';
