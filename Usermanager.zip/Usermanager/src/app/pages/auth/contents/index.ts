export { LoginComponent as LoginPage } from './login/login.component';
export { RegisterComponent as RegisterPage } from './register/register.component';
