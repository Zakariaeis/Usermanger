export { SNACK_DATA } from './snack-message.model';
