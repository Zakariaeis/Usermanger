export interface SNACK_DATA {
  message: string;
  duration?: number;
  action?: string;
}
