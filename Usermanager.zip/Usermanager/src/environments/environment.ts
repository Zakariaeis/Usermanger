export const environment = {
  production: false,
  apiUrl: 'http://localhost:3000',
  userRoles: ['Banned', 'Customer', 'Admin', 'Super Admin'],
};

// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
